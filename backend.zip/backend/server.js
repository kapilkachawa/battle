const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const db = require('./database');

const app = express();
app.use(cors());
app.use(express.json());

// File upload configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  }
});
const upload = multer({ 
  storage: storage,
  limits: { fileSize: 2 * 1024 * 1024 } // 2MB limit
});

// Team Registration Endpoint
app.post('/api/register', upload.single('paymentProof'), async (req, res) => {
  const {
    college,
    teamName,
    teamLeaderName,
    teamLeaderWhatsApp,
    teamLeaderUID,
    teamLeaderInGameName,
    player2Name,
    player2UID,
    player2InGameName,
    player3Name,
    player3UID,
    player3InGameName,
    player4Name,
    player4UID,
    player4InGameName
  } = req.body;

  const paymentProof = req.file ? req.file.filename : null;

  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();

    const [result] = await connection.query(
      `INSERT INTO team_registrations 
      (college, team_name, team_leader_name, team_leader_whatsapp, 
      team_leader_uid, team_leader_ingame_name, 
      player2_name, player2_uid, player2_ingame_name,
      player3_name, player3_uid, player3_ingame_name,
      player4_name, player4_uid, player4_ingame_name,
      payment_proof, registration_date) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        college, teamName, teamLeaderName, teamLeaderWhatsApp,
        teamLeaderUID, teamLeaderInGameName,
        player2Name, player2UID, player2InGameName,
        player3Name, player3UID, player3InGameName,
        player4Name, player4UID, player4InGameName,
        paymentProof
      ]
    );

    await connection.commit();
    res.status(201).json({ 
      message: 'Registration Successful', 
      teamId: result.insertId 
    });
  } catch (error) {
    await connection.rollback();
    console.error('Registration Error:', error);
    res.status(500).json({ message: 'Registration Failed', error: error.message });
  } finally {
    connection.release();
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});